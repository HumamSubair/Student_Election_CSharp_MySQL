﻿
namespace Student__Coordinator_Election
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label student_IdLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.Label lblX;
            this.lblCountVotes = new System.Windows.Forms.Label();
            this.txtST_ID = new System.Windows.Forms.TextBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnVote = new System.Windows.Forms.Button();
            this.RBMiles = new System.Windows.Forms.RadioButton();
            this.RBGwen = new System.Windows.Forms.RadioButton();
            this.RBPeter = new System.Windows.Forms.RadioButton();
            student_IdLabel = new System.Windows.Forms.Label();
            lblX = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblCountVotes
            // 
            this.lblCountVotes.AutoSize = true;
            this.lblCountVotes.ForeColor = System.Drawing.Color.White;
            this.lblCountVotes.Location = new System.Drawing.Point(266, 360);
            this.lblCountVotes.Name = "lblCountVotes";
            this.lblCountVotes.Size = new System.Drawing.Size(65, 13);
            this.lblCountVotes.TabIndex = 23;
            this.lblCountVotes.Text = "Count Votes";
            this.lblCountVotes.Click += new System.EventHandler(this.lblCountVotes_Click_1);
            // 
            // student_IdLabel
            // 
            student_IdLabel.AutoSize = true;
            student_IdLabel.ForeColor = System.Drawing.Color.White;
            student_IdLabel.Location = new System.Drawing.Point(11, 61);
            student_IdLabel.Name = "student_IdLabel";
            student_IdLabel.Size = new System.Drawing.Size(59, 13);
            student_IdLabel.TabIndex = 21;
            student_IdLabel.Text = "Student Id:";
            // 
            // txtST_ID
            // 
            this.txtST_ID.Location = new System.Drawing.Point(76, 54);
            this.txtST_ID.Name = "txtST_ID";
            this.txtST_ID.Size = new System.Drawing.Size(242, 20);
            this.txtST_ID.TabIndex = 22;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(228, 115);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(90, 113);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 20;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(119, 115);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(93, 113);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 19;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 115);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(91, 113);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 18;
            this.pictureBox1.TabStop = false;
            // 
            // btnVote
            // 
            this.btnVote.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVote.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnVote.Location = new System.Drawing.Point(98, 292);
            this.btnVote.Name = "btnVote";
            this.btnVote.Size = new System.Drawing.Size(110, 35);
            this.btnVote.TabIndex = 17;
            this.btnVote.Text = "Vote";
            this.btnVote.UseVisualStyleBackColor = true;
            this.btnVote.Click += new System.EventHandler(this.btnVote_Click);
            // 
            // RBMiles
            // 
            this.RBMiles.AutoSize = true;
            this.RBMiles.ForeColor = System.Drawing.Color.White;
            this.RBMiles.Location = new System.Drawing.Point(242, 246);
            this.RBMiles.Name = "RBMiles";
            this.RBMiles.Size = new System.Drawing.Size(49, 17);
            this.RBMiles.TabIndex = 16;
            this.RBMiles.TabStop = true;
            this.RBMiles.Text = "Miles";
            this.RBMiles.UseVisualStyleBackColor = true;
            // 
            // RBGwen
            // 
            this.RBGwen.AutoSize = true;
            this.RBGwen.ForeColor = System.Drawing.Color.White;
            this.RBGwen.Location = new System.Drawing.Point(130, 246);
            this.RBGwen.Name = "RBGwen";
            this.RBGwen.Size = new System.Drawing.Size(53, 17);
            this.RBGwen.TabIndex = 15;
            this.RBGwen.TabStop = true;
            this.RBGwen.Text = "Gwen";
            this.RBGwen.UseVisualStyleBackColor = true;
            // 
            // RBPeter
            // 
            this.RBPeter.AutoSize = true;
            this.RBPeter.ForeColor = System.Drawing.Color.White;
            this.RBPeter.Location = new System.Drawing.Point(26, 246);
            this.RBPeter.Name = "RBPeter";
            this.RBPeter.Size = new System.Drawing.Size(50, 17);
            this.RBPeter.TabIndex = 14;
            this.RBPeter.TabStop = true;
            this.RBPeter.Text = "Peter";
            this.RBPeter.UseVisualStyleBackColor = true;
            // 
            // lblX
            // 
            lblX.AutoSize = true;
            lblX.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lblX.ForeColor = System.Drawing.Color.Red;
            lblX.Location = new System.Drawing.Point(309, 7);
            lblX.Name = "lblX";
            lblX.Size = new System.Drawing.Size(25, 23);
            lblX.TabIndex = 24;
            lblX.Text = "X";
            lblX.Click += new System.EventHandler(this.lblX_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(341, 394);
            this.Controls.Add(lblX);
            this.Controls.Add(this.lblCountVotes);
            this.Controls.Add(student_IdLabel);
            this.Controls.Add(this.txtST_ID);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnVote);
            this.Controls.Add(this.RBMiles);
            this.Controls.Add(this.RBGwen);
            this.Controls.Add(this.RBPeter);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCountVotes;
        private System.Windows.Forms.TextBox txtST_ID;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnVote;
        private System.Windows.Forms.RadioButton RBMiles;
        private System.Windows.Forms.RadioButton RBGwen;
        private System.Windows.Forms.RadioButton RBPeter;
    }
}

