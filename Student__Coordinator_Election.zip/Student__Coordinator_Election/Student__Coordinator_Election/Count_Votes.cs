﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student__Coordinator_Election
{
    public partial class Count_Votes : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HUMAM-SUBAIR\Documents\Election.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cm = new SqlCommand();
        SqlDataReader dr;


        string reg_No;
        string vote;

        public Count_Votes()
        {
            InitializeComponent();

            DataGrid();

        }

        public void DataGrid()
        {
            try
            {
                cm = new SqlCommand("SELECT reg_No, vote FROM votes", con);
                con.Open();
                dr = cm.ExecuteReader();

                while (dr.Read())
                {
                    reg_No = dr["reg_No"].ToString();
                    vote = dr["vote"].ToString();
                    dataGridView1.Rows.Add(reg_No, vote);
                }

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            int i = 0;
            try
            {
                if (RBPeter.Checked == true)
                {

                    dataGridView2.Rows.Clear();
                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {

                        if (row.Cells["Column2"].Value != null && row.Cells["Column2"].Value.ToString() == "Peter")
                        {
                            i++;
                            reg_No = row.Cells["Column1"].Value.ToString();
                            vote = row.Cells["Column2"].Value.ToString();
                            dataGridView2.Rows.Add(i, reg_No, vote);
                        }
                    }
                }

                else if (RBGwen.Checked == true)
                {
                    dataGridView2.Rows.Clear();

                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {

                        if (row.Cells["Column2"].Value != null && row.Cells["Column2"].Value.ToString() == "Gwen")
                        {
                            i++;
                            reg_No = row.Cells["Column1"].Value.ToString();
                            vote = row.Cells["Column2"].Value.ToString();
                            dataGridView2.Rows.Add(i, reg_No, vote);
                        }
                    }
                }

                else if (RBMiles.Checked == true)
                {
                    dataGridView2.Rows.Clear();


                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {

                        if (row.Cells["Column2"].Value != null && row.Cells["Column2"].Value.ToString() == "Miles")
                        {
                            i++;
                            reg_No = row.Cells["Column1"].Value.ToString();
                            vote = row.Cells["Column2"].Value.ToString();
                            dataGridView2.Rows.Add(i, reg_No, vote);
                        }
                    }
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        private void lblX_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you Sure want to Exit the Application", "Confirm Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Dispose();
            }
        }
    }
}
