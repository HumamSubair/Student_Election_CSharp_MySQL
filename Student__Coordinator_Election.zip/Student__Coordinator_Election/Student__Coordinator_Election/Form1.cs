﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student__Coordinator_Election
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HUMAM-SUBAIR\Documents\Election.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cm = new SqlCommand();

        public void clear()
        {
            txtST_ID.Clear();
            RBPeter.Checked = false;
            RBGwen.Checked = false;
            RBMiles.Checked = false;
        }

        private void lblX_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you Sure want to Exit the Application", "Confirm Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question)== DialogResult.Yes){
                Application.Exit();
            }
        }


        private void lblCountVotes_Click_1(object sender, EventArgs e)
        {
            new Count_Votes().Show();

        }

        private void btnVote_Click(object sender, EventArgs e)
        {
            string reg_No = txtST_ID.Text;
            string vote;
            try
            {
                if (reg_No != "")
                {
                    if (RBPeter.Checked == true)
                    {
                        vote = "Peter";
                        cm = new SqlCommand("insert into votes(Reg_No, vote) values (@reg_No, @vote)", con);
                        cm.Parameters.AddWithValue("@reg_No", reg_No);
                        cm.Parameters.AddWithValue("@vote", vote);
                        con.Open();

                        cm.ExecuteNonQuery();
                        con.Close();
                        MessageBox.Show("Voted Successfully.");
                        clear();
                    }
                    else if (RBGwen.Checked == true)
                    {
                        vote = "Gwen";
                        cm = new SqlCommand("insert into votes(Reg_No, vote) values (@reg_No, @vote)", con);
                        cm.Parameters.AddWithValue("@reg_No", reg_No);
                        cm.Parameters.AddWithValue("@vote", vote);
                        con.Open();

                        cm.ExecuteNonQuery();
                        con.Close();
                        MessageBox.Show("Voted Successfully.");
                        clear();
                    }
                    else if (RBMiles.Checked == true)
                    {
                        vote = "Miles";
                        cm = new SqlCommand("insert into votes(Reg_No, vote) values (@reg_No, @vote)", con);
                        cm.Parameters.AddWithValue("@reg_No", reg_No);
                        cm.Parameters.AddWithValue("@vote", vote);
                        con.Open();

                        cm.ExecuteNonQuery();
                        con.Close();
                        MessageBox.Show("Voted Successfully.");
                        clear();
                    }
                    else
                    {
                        MessageBox.Show("Try Again!!");
                    }
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
